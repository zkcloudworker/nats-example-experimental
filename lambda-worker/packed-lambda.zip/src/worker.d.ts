import { zkCloudWorker, Cloud } from "zkcloudworker";
export declare class ExampleWorker extends zkCloudWorker {
    constructor(cloud: Cloud);
    execute(transactions: string[]): Promise<string | undefined>;
}
export declare function zkcloudworker(cloud: Cloud): Promise<zkCloudWorker>;
