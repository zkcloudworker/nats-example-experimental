"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const zkcloudworker_1 = require("zkcloudworker");
const worker_1 = require("./src/worker");
const handler = async (event, context) => {
    console.log('EVENT: \n' + JSON.stringify(event, null, 2));
    console.log('LOGGER: ' + context.logStreamName);
    const timeCreated = Date.now();
    const job = {
        id: "local",
        jobId: "jobId",
        developer: "@dfst",
        repo: "lambda-simple-example",
        task: "example",
        userId: "userId",
        args: Math.ceil(Math.random() * 100).toString(),
        metadata: "simple-example",
        txNumber: 1,
        timeCreated,
        timeCreatedString: new Date(timeCreated).toISOString(),
        timeStarted: timeCreated,
        jobStatus: "started",
        maxAttempts: 0,
    };
    const cloud = new zkcloudworker_1.LocalCloud({
        job,
        chain: "local",
        localWorker: worker_1.zkcloudworker
    });
    const worker = await (0, worker_1.zkcloudworker)(cloud);
    console.log("Executing job...");
    console.log("Job:", JSON.stringify(job, null, 2));
    const result = await worker.execute([]);
    console.log("Job result:", result);
    return {
        statusCode: 200,
        body: JSON.stringify(result)
    };
};
exports.handler = handler;
